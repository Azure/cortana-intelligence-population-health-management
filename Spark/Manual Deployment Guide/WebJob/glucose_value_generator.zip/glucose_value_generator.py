'''
glucose_value_generator.py
Generates random glucose readings as streaming data sent to the Event Hub.
'''

import json, random, os
from azure.storage.blob import BlockBlobService
from azure.servicebus import ServiceBusService
from io import StringIO

storage_name = os.environ['storage_name']
storage_key = os.environ['storage_key']
eh_namespace = os.environ['eh_namespace']
eh_key_value = os.environ['eh_key']

# these values were specified in the guide and therefore hard-coded here
eh_name = 'glucoseeventhub'
eh_key_name = 'RootManageSharedAccessKey'
glucose_mean = 5
glucose_sd = 3
glucose_n = 10  # number of glucose readings to submit per patient

# connect to blob and get the patient numbers
blob_service = BlockBlobService(storage_name, storage_key)
patient_nbrs = [x.name.split('.')[0] for x in blob_service.list_blobs(container_name='patientrecords')]

# send a message for each patient
sbs = ServiceBusService(service_namespace=eh_namespace,
                        shared_access_key_name=eh_key_name,
                        shared_access_key_value=eh_key_value)
for _ in range(glucose_n):
    for patient_nbr in patient_nbrs:
        msg = {'patient_nbr': patient_nbr,
               'glucoseLevel': abs(random.normalvariate(glucose_mean, glucose_sd))}
        sbs.send_event(eh_name, json.dumps(msg))